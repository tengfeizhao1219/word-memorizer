# TabBar 图标目录

## 需要的图标文件
```
home.png           # 首页图标
home-active.png    # 首页选中图标
words.png          # 生词图标
words-active.png   # 生词选中图标
review.png         # 复习图标
review-active.png  # 复习选中图标
stats.png          # 统计图标
stats-active.png   # 统计选中图标
```

## 图标规格
- 尺寸: 81px × 81px
- 格式: PNG (透明背景)
- 颜色: 建议使用单色或简单图标

## 临时解决方案
目前使用1x1像素的透明图片作为占位符，实际使用时需要替换为真实图标。

## 图标来源建议
1. 使用微信小程序官方图标库
2. 使用阿里巴巴图标库 (iconfont.cn)
3. 设计自定义图标
4. 使用免费图标资源网站